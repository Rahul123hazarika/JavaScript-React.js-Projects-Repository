
import Counter from './components/Exercise1/Counter.jsx';


function App() {
  return (
    <div>
      <Counter></Counter>
    </div>
  );
}

export default App;
