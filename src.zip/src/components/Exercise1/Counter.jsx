import React, {useState} from "react"; 
/***
 * const:Used because the variable reference never changes
 * we use usestate for manage component state 
 * event handler : function that response to user interactions
 * controller :input field whose value is controlled by react state
***/
const Counter =()=>{
    const[count , setCount]=useState(0);
    //state to store the value type inside the input field
    const[inputValue, setInputValue]=useState('');
    /**
     * now i am going to do increment handler 
     * increased count by one when increment button clicked 
     */
    const handelIncrement=()=>{
        setCount(count+1);

    };
    /**
     * Decrement handler
     * whenver we clicked on button it will decrement value of count
     */
    const handelDecrement =()=>{
        setCount(count-1);
    }

    // reset handler
    const reset=()=>{
        setCount(0);
        setInputValue(''); // Also clear the input field
    }
    /**
     * * Input Change Handler
   * Updates inputValue state whenever user types in the input field
   * e.target.value contains the current value of the input
     */
    const inputhandler =(e)=>{
        setInputValue(e.target.value); 
    
    };
      /**
   * Set Custom Count Handler
   * Sets the count to the value entered in the input field
   * parseInt converts string to number
   * || 0 ensures if input is empty or invalid, count becomes 0
   */
  const handlecustom =()=>{
    const customvalue=parseInt(inputValue)||0;
    setCount(customvalue);
    setInputValue(''); // clear input after setting 
  };
  return(
   <div className="container mt-5">
      <div className="card shadow-sm">
        <div className="card-header bg-primary text-white">
          <h3 className="mb-0">Counter Application</h3>
        </div>
        <div className="card-body text-center">
          {/* Display current count with large text */}
          <h1 className="display-1 text-primary mb-4">{count}</h1>
          
          {/* Button group for increment, decrement, and reset */}
          <div className="btn-group mb-4" role="group">
            <button 
              className="btn btn-success btn-lg" 
              onClick={handelDecrement}
            >
              <i className="bi bi-dash"></i> Decrement
            </button>
            <button 
              className="btn btn-danger btn-lg" 
              onClick={reset}
            >
              <i className="bi bi-arrow-clockwise"></i> Reset
            </button>
            <button 
              className="btn btn-success btn-lg" 
              onClick={handelIncrement}
            >
              <i className="bi bi-plus"></i> Increment
            </button>
          </div>

          {/* Custom count input section */}
          <div className="row justify-content-center">
            <div className="col-md-6">
              <div className="input-group">
                <input
                  type="number"
                  className="form-control"
                  placeholder="Enter custom count"
                  value={inputValue}
                  onChange={inputhandler}
                />
                <button 
                  className="btn btn-outline-primary" 
                  onClick={handlecustom }
                >
                  Set Count
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

};
export default Counter;